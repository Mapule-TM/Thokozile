package com.digibank.transactions.services;

import com.digibank.transactions.entities.Transaction;

public interface TransactionsI {

		Boolean saveTransactions(Transaction transaction);
}
{
	p

}