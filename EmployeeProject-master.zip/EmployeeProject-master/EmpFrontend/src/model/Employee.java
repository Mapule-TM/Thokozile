package model;

import java.io.Serializable;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import entities.EmployeeEntity;

public class Employee {
	

		@ManagedBean(name = "employee")
		@SessionScoped
		public class Employee implements Serializable {
			private static final long serialVersionUID = 1L;
			
			private String name;
			private String surname;
			private Date dateOfBirth;
		
		
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public String getSurName() {
				return surname;
			}
			public void setSurName(String surname) {
				this.surName = surname;
			}
			public Date getDateOfBirth() {
				return dateOfBirth;
			}
			public void setDateOfBirth(Date dateOfBirth) {
				this.dateOfBirth = dateOfBirth;
			}
			
			public EmployeeEntity getEntity()
			{
				EmployeeEntity employeeEntity = new EmployeeEntity();
				employeeEntity.setDateOfBirth(dateOfBirth);
				employeeEntity.setName(name);
				employeeEntity.setSurName(surname);
				return employeeEntity;
			}
	}
}
