package com.gui.controller;

import java.util.List;

import javax.annotation.ManagedBean;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;

import com.ejb.service.EmpService;
import com.jpa.entities.Employee;

@ManagedBean(name = "employees", eager = true)
@SessionScoped
public class EmpController {
	@EJB
	EmpService employeeService;
	
	private String empName;
	private String empSurname;
	private String empDateOfBirth;
	//private String empEmailAddr;
	//private double empSalary;
	
	public List<Employee> getEmployees(){
		return employeeService.findAllEmployees();
	}

	public EmpController(String name, String surname, String dateOfBirth) {
		this.empName = name;
		this.empSurname = surname;
		this.empDateOfBirth = dateOfBirth;
	}
	
	public EmpController() {
		
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpSurname() {
		return empSurname;
	}

	public void setEmpSurname(String empSurname) {
		this.empSurname = empSurname;
	}

	public String getDateOfBirth() {
		return empDateOfBirth;
	}

	public void setEmpContact(String empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}

	/*public String getEmpEmail() {
		return empEmailAddr;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmailAddr = empEmail;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}*/
	
}
