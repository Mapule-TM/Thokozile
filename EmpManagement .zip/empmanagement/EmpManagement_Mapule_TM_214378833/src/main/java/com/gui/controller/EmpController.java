package com.gui.controller;

import java.util.List;

import com.ejb.service.EmpService;
import com.jpa.entities.Employee;

@ManagedBean(name = "employees", eager = true)
@SessionScoped
public class EmpController {

	@EJB
	EmpService employeeService;
	
	private String empName;
	private String empSurname;
	private String empCellNo;
	private String empEmailAddr;
	private double empSalary;
	
	public List<Employee> getEmployees(){
		return employeeService.findAllEmployees();
	}

	public EmpController(String empName, String empSurname, String empContact, String empEmail, double empSalary) {
		this.empName = empName;
		this.empSurname = empSurname;
		this.empCellNo = empContact;
		this.empEmailAddr = empEmail;
		this.empSalary = empSalary;
	}
	
	public EmpController() {
		
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpSurname() {
		return empSurname;
	}

	public void setEmpSurname(String empSurname) {
		this.empSurname = empSurname;
	}

	public String getEmpContact() {
		return empCellNo;
	}

	public void setEmpContact(String empContact) {
		this.empCellNo = empContact;
	}

	public String getEmpEmail() {
		return empEmailAddr;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmailAddr = empEmail;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	
	
}
